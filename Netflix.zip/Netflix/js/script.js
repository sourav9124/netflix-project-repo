	function signin()
		{
			let email=document.myform.email.value;
			let password=document.myform.password.value;
			
			


			if(email=="")
			{
				alert("Email field is empty");
				return false;
			}
			else if(password.length <=6)
			{
				alert("password should be less than 7 characters");
				return false;
		    }
			
			alert("Form submitted");
			

		}


function signup()
		{
			let name=document.myform.name.value;
			let password=document.myform.password.value;
			let email=document.myform.email.value;
			


			if(name=="")
			{
				alert("Name field is empty");
				return false;
			}
			else if(password.length <=6)
			{
				alert("password should be less than 7 characters");
				return false;
			}
			else if(email=="")
			{
				alert("email field is empty");
				return false;
			}
			
			alert("Form submitted");
			

		}